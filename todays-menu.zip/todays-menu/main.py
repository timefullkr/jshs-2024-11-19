# main.py

import os
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from dotenv import load_dotenv
from datetime import datetime, timedelta
from pathlib import Path
from database import Database
from neis_api import NeisService
from chatgpt_api import GPT_Client_API
from websocket_manager import ConnectionManager
import json


load_dotenv()
# 기본 설정
BASE_DIR = Path(__file__).resolve().parent

# FastAPI 앱 초기화
app = FastAPI()
app.mount("/templates", StaticFiles(directory=str(BASE_DIR / "templates")), name="templates")
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")
app.mount("/js", StaticFiles(directory=str(BASE_DIR / "templates" / "js")), name="js")
app.mount("/css", StaticFiles(directory=str(BASE_DIR / "static" / "css")), name="css")

# 데이터베이스 초기화
db = Database(str(BASE_DIR / "data" / "school_meals.db"))
db.init_db()

# NEIS 서비스 초기화
neis_api = NeisService(api_key=os.getenv('NEIS_API_KEY'))

# AI 서비스 초기화
ai_client = GPT_Client_API().create()

if not ai_client:
    raise RuntimeError("Failed to initialize AI service")


ws_manager = ConnectionManager()

# WebSocket 엔드포인트 추가
@app.websocket("/ws")
async def websocket_endpoint(
    websocket: WebSocket,
):
    client_id = websocket.query_params.get("client_id")
    if not client_id:
        raise WebSocketDisconnect("Client ID is required")
        
    await ws_manager.connect(websocket, client_id)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        await ws_manager.disconnect(client_id)
            
# API 라우트
@app.get("/")
async def home():
    """메인 페이지"""
    today = datetime.now().strftime("%Y%m%d")
    await db.increment_visits(today)
    return FileResponse(str(BASE_DIR / "templates" / "html" / "index.html"))

@app.get("/api/visits/today")
async def get_today_visits():
    """오늘의 방문자 수"""
    today = datetime.now().strftime("%Y%m%d")
    count = await db.get_today_visits(today)
    return {"count": count}

@app.get("/api/meals/{date}")
async def get_meals(date: str):
    """급식 정보 조회"""
    try:
        target_date = datetime.strptime(date, "%Y-%m-%d")
        date_str = target_date.strftime("%Y%m%d")

        meals = await db.get_meals(date_str)
        if not meals:
            meals = await neis_api.fetch_school_meals(target_date, db)
        return meals
    except ValueError:
        raise HTTPException(status_code=400, detail="유효하지 않은 날짜 형식입니다.")
    except Exception as e:
        print(f"Error in get_meals: {str(e)}")
        raise HTTPException(status_code=500, detail="서버 내부 오류가 발생했습니다.")

@app.get("/api/review/{date}/{school_code}")
async def get_review(date: str, school_code: str):
    """리뷰 조회 및 생성"""
    try:
        target_date = datetime.strptime(date, "%Y-%m-%d")
        date_str = target_date.strftime("%Y%m%d")

        review = await db.get_review(date_str, school_code)
        if not review:
            meals = await db.get_meals(date_str)
            meal = next((m for m in meals if m['school_code'] == school_code), None)

            if meal and meal.get('lunch_menu'):
                try:
                    review_text, nutri_score, pref_score = await ai_client.generate_menu_review(meal['lunch_menu'])
                    error_flag = 0
                except Exception as e:
                    print(f"Review generation error: {str(e)}")
                    review_text = "리뷰를 생성하는 중 오류가 발생했습니다."
                    nutri_score = 0
                    pref_score = 0
                    error_flag = 1

                await db.save_review(date_str, school_code, review_text, nutri_score, pref_score, error_flag)

                if error_flag == 0:
                    review = {
                        "review": review_text,
                        "nutri_score": nutri_score,
                        "pref_score": pref_score,
                        "reactions": {"likes": 0}
                    }
                else:
                    return {
                        "review": review_text,
                        "nutri_score": 0,
                        "pref_score": 0,
                        "nutri_stars": "",
                        "pref_stars": "",
                        "reactions": {"likes": 0}
                    }
        return review
    except ValueError:
        raise HTTPException(status_code=400, detail="유효하지 않은 날짜 형식입니다.")
    except Exception as e:
        print(f"Error in get_review: {str(e)}")
        raise HTTPException(status_code=500, detail="서버 내부 오류가 발생했습니다.")

@app.post("/api/reaction/{date}/{school_code}/{reaction_type}")
async def handle_reaction(date: str, school_code: str, reaction_type: str):
    """반응 처리"""
    try:
        if reaction_type != "like":
            raise HTTPException(status_code=400, detail="Invalid reaction type")

        target_date = datetime.strptime(date, "%Y-%m-%d")
        date_str = target_date.strftime("%Y%m%d")

        result = await db.handle_reaction(date_str, school_code, reaction_type)
        
        # 반응이 성공적으로 처리된 경우, 모든 클라이언트에게 업데이트 브로드캐스트
        if result:
            message = json.dumps({
                "type": "reaction",
                "school_code": school_code,
                "likes": result.get("likes", 0)
            })
            await ws_manager.broadcast(message)

        return result

    except ValueError:
        raise HTTPException(status_code=400, detail="유효하지 않은 날짜 형식입니다.")
    except Exception as e:
        print(f"Error in handle_reaction: {str(e)}")
        raise HTTPException(status_code=500, detail="서버 내부 오류가 발생했습니다.")

@app.get("/api/reactions/{date}")
async def get_all_reactions(date: str):
    """모든 학교의 반응 수 가져오기"""
    try:
        target_date = datetime.strptime(date, "%Y-%m-%d")
        date_str = target_date.strftime("%Y%m%d")
        result = await db.handle_reaction_all(date_str )
        return result
    except ValueError:
        raise HTTPException(status_code=400, detail="유효하지 않은 날짜 형식입니다.")
    except Exception as e:
        print(f"Error in get_all_reactions: {str(e)}")
        raise HTTPException(status_code=500, detail="서버 내부 오류가 발생했습니다.")

@app.get("/api/visits/total")
async def get_total_visits():
    """총 방문자 수 조회"""
    count = await db.get_total_visits()
    return {"count": count}

@app.get("/api/dates")
async def get_dates():
    """날짜 범위 조회"""
    today = datetime.now()
    dates = [(today + timedelta(days=i)).strftime("%Y-%m-%d") for i in range(-3, 4)]
    return {"dates": dates, "selected_date": today.strftime("%Y-%m-%d")}




if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host=os.getenv("HOST_IP"), port=int(os.getenv("HOST_PORT")), reload=True)
