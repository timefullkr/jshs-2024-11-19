# database.py

import os
import sqlite3
import asyncio
from pathlib import Path

class Database:
    def __init__(self, db_path: str):
        self.db_path = db_path
        
    def init_db(self):
        """데이터베이스 초기화"""
        with sqlite3.connect(self.db_path) as conn:
            c = conn.cursor()
            # 급식 테이블
            c.execute('''
                CREATE TABLE IF NOT EXISTS meals (
                    date TEXT,
                    school_code TEXT,
                    school_name TEXT,
                    lunch_menu TEXT,
                    PRIMARY KEY (date, school_code)
                )
            ''')
            # 리뷰 테이블
            c.execute('''
                CREATE TABLE IF NOT EXISTS reviews (
                    date TEXT,
                    school_code TEXT,
                    review_text TEXT,
                    nutri_score REAL,
                    pref_score REAL,
                    error_flag INTEGER DEFAULT 0,
                    PRIMARY KEY (date, school_code)
                )
            ''')
            # 반응 테이블 (싫어요 컬럼 제거)
            c.execute('''
                CREATE TABLE IF NOT EXISTS reactions (
                    date TEXT,
                    school_code TEXT,
                    likes INTEGER DEFAULT 0,
                    PRIMARY KEY (date, school_code)
                )
            ''')
            # 방문자 테이블
            c.execute('''
                CREATE TABLE IF NOT EXISTS visits (
                    date TEXT PRIMARY KEY,
                    count INTEGER DEFAULT 0
                )
            ''')

    async def execute(self, query: str, params: tuple = None) -> list:
        """비동기 데이터베이스 실행 함수"""
        def _execute():
            with sqlite3.connect(self.db_path) as conn:
                cur = conn.cursor()
                if params:
                    cur.execute(query, params)
                else:
                    cur.execute(query)
                conn.commit()
                return cur.fetchall()
        return await asyncio.to_thread(_execute)

    # 급식 관련 메서드
    async def get_meals(self, date_str: str) -> list:
        """급식 정보 조회"""
        rows = await self.execute('''
            SELECT school_code, school_name, lunch_menu
            FROM meals
            WHERE date = ? AND lunch_menu != '급식 정보 없음'
        ''', (date_str,))
        return [{"school_code": row[0], "school_name": row[1], "lunch_menu": row[2]} for row in rows]

    async def save_meal(self, date_str: str, school_code: str, school_name: str, menu: str):
        """급식 정보 저장"""
        await self.execute(
            'INSERT OR REPLACE INTO meals (date, school_code, school_name, lunch_menu) VALUES (?, ?, ?, ?)',
            (date_str, school_code, school_name, menu)
        )

    # 리뷰 관련 메서드
    async def get_review(self, date_str: str, school_code: str):
        """리뷰 정보 조회"""
        rows = await self.execute('''
            SELECT r.review_text, r.error_flag, r.nutri_score, r.pref_score,
                   COALESCE(rc.likes, 0) as likes
            FROM reviews r
            LEFT JOIN reactions rc ON r.date = rc.date AND r.school_code = rc.school_code
            WHERE r.date = ? AND r.school_code = ?
        ''', (date_str, school_code))

        if rows:
            row = rows[0]
            error_flag = row[1]
            if error_flag:
                return None

            nutri_score = float(row[2])
            pref_score = float(row[3])
            
            return {
                "review": row[0],
                "nutri_score": nutri_score,
                "pref_score": pref_score,
                "reactions": {"likes": row[4]}
            }
        return None

    async def save_review(self, date_str: str, school_code: str, review_text: str, nutri_score: float, pref_score: float, error_flag: int = 0):
        """리뷰 저장"""
        await self.execute(
            '''INSERT OR REPLACE INTO reviews 
            (date, school_code, review_text, nutri_score, pref_score, error_flag) 
            VALUES (?, ?, ?, ?, ?, ?)''',
            (date_str, school_code, review_text, nutri_score, pref_score, error_flag)
        )

    # 반응 관련 메서드
    async def handle_reaction_all(self, date_str: str):
        result = await self.execute(
            'SELECT school_code, likes FROM reactions WHERE date = ?',
            (date_str,)
        )
        
        if result:
            reactions = {}
            for row in result:
                school_code, likes = row
                reactions[school_code] = {"likes": likes}
            return reactions
        return {}

    async def handle_reaction(self, date_str: str, school_code: str, reaction_type: str):
        """반응 처리"""
        # 레코드가 없으면 생성
        await self.execute(
            'INSERT OR IGNORE INTO reactions (date, school_code, likes) VALUES (?, ?, 0)',
            (date_str, school_code)
        )

        # 좋아요 업데이트
        if reaction_type == 'like':
            await self.execute(
                'UPDATE reactions SET likes = likes + 1 WHERE date = ? AND school_code = ?',
                (date_str, school_code)
            )

        # 업데이트된 값 조회
        result = await self.execute(
            'SELECT likes FROM reactions WHERE date = ? AND school_code = ?',
            (date_str, school_code)
        )
        
        if result:
            likes = result[0][0]
            return {"school_code": school_code, "likes": likes}
        return {}
    
    # 방문자 관련 메서드
    async def increment_visits(self, date_str: str) -> int:
        """방문자 수 증가"""
        await self.execute(
            'INSERT INTO visits (date, count) VALUES (?, 1) ON CONFLICT(date) DO UPDATE SET count = count + 1',
            (date_str,)
        )
        result = await self.execute('SELECT count FROM visits WHERE date = ?', (date_str,))
        return result[0][0] if result else 0

    async def get_today_visits(self, date_str: str) -> int:
        """오늘의 방문자 수 조회"""
        result = await self.execute('SELECT count FROM visits WHERE date = ?', (date_str,))
        return result[0][0] if result else 0

    async def get_total_visits(self) -> int:
        """총 방문자 수 조회"""
        result = await self.execute('SELECT COALESCE(SUM(count), 0) FROM visits')
        return result[0][0] if result else 0
