$(document).ready(function() {
    // 웹소켓 연결 초기화
    const socket = connectWebSocket();
});
function connectWebSocket() {
    // localStorage에서 client_id 가져오기
    let clientId = localStorage.getItem('client_id');
    if (!clientId) {
        // 새로운 client_id 생성
        clientId = generateUUID();
        localStorage.setItem('client_id', clientId);
    }

    const protocol = window.location.protocol === 'https:' ? 'wss' : 'ws';
    const socketUrl = `${protocol}://${window.location.host}/ws?client_id=${clientId}`;

    const socket = new WebSocket(socketUrl);

    socket.onopen = function() {
        console.log('WebSocket 연결됨');
    };

    socket.onmessage = function(event) {
        
        const data = JSON.parse(event.data);
        if (data.type === 'connection_count') {
            // 접속자 수 업데이트 UI 처리
           $('#connection-count').text(data.count);
        }
        if (data.type === 'reaction') {
            // 좋아요 수 업데이트 UI 처리
            const card = $(`#school-${data.school_code}`);
            update_count_ReactionUI(card, data.likes);
        }

    };

    socket.onclose = function() {
        console.log('WebSocket 연결 종료. 재접속 시도...');
        setTimeout(connectWebSocket, 5000);
    };

    return socket;
}

function generateUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        const r = Math.random() * 16 | 0;
        const v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}
