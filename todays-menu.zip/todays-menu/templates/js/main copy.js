$(document).ready(function() {
    const $mealsContainer = $('#meals-container');
    const $loading = $('.loading');
    const $dateButtons = $('#date-buttons');
    let currentDate = '';

    // 자동 갱신 인터벌을 저장할 변수
    let autoRefreshInterval = null;

    function updateVisitCount() {
        $.ajax({
            url: '/api/visits/total',
            method: 'GET',
            success: function(response) {
                $('#visit-counter').text(response.count);
            },
            error: function(error) {
                console.error('Error fetching visit count:', error);
            }
        });
    }

    function fetchMeals(date) {
        $loading.css('display', 'flex');
        currentDate = date;
        $mealsContainer.empty();

        // 자동 갱신 중지
        stopAutoRefresh();

        $.ajax({
            url: `/api/meals/${date}`,
            method: 'GET',
            success: function(meals) {
                // 학교명으로 정렬
                meals.sort((a, b) => a.school_name.localeCompare(b.school_name, 'ko'));

                meals.forEach((meal, index) => {
                    const cardHtml = createBasicCard(meal, index);
                    const $cardCol = $(cardHtml);
                    $mealsContainer.append($cardCol);

                    // 리뷰 로드
                    loadReview(meal.school_code, date);
                });

                // 좋아요 데이터 갱신 및 자동 갱신 시작
                // refreshLikesAndReposition();
                startAutoRefresh();
            },
            error: function(xhr, status, error) {
                console.error('Error:', error);
                $mealsContainer.html(`
                    <div class="col-12 text-center">
                        <div class="alert alert-danger" role="alert">
                            데이터를 불러오는 중 오류가 발생했습니다.
                        </div>
                    </div>
                `);
                $loading.fadeOut();
            },
            complete: function() {
                $loading.fadeOut();
            }
        });
    }

    function loadReview(schoolCode, date) {
        const card = $(`#school-${schoolCode}`);
        
        const cardCol = card.closest('.card-col');
        const reviewContainer = card.find('.review-container');
        const reviewLoading = card.find('.review-loading');

        reviewLoading.show();

        $.ajax({
            url: `/api/review/${date}/${schoolCode}`,
            method: 'GET',
            success: function(review) {
                debugger
                if (review) {
                    reviewContainer.html(`
                        <p class="card-text">${review.review}</p>
                    `);

                    card.find('.nutri-score').html(createStars(review.nutri_score));
                    card.find('.pref-score').html(createStars(review.pref_score));

                    // 총점 계산 및 저장
                    const totalScore = (review.nutri_score || 0) + (review.pref_score || 0);
                    cardCol.data('totalScore', totalScore);
                    update_count_ReactionUI(card, review.reactions);

                    // 카드 재배치
                    repositionCard(cardCol);
                } else {
                    reviewContainer.html(`
                        <div class="alert alert-warning" role="alert">
                            리뷰가 존재하지 않습니다.
                        </div>
                    `);
                    cardCol.data('totalScore', 0);
                }
            },
            error: function(xhr, status, error) {
                reviewContainer.html(`
                    <div class="alert alert-danger" role="alert">
                        리뷰를 불러오는 중 오류가 발생했습니다.
                    </div>
                `);
                cardCol.data('totalScore', 0);
            },
            complete: function() {
                reviewLoading.hide();
            }
        });
    }

    function repositionCard(cardCol) {
        const totalScore = cardCol.data('totalScore') || 0;
        const $cardCols = $mealsContainer.children('.card-col');

        // 현재 위치 저장
        const currentIndex = $cardCols.index(cardCol);

        // 기존 카드들과 비교하여 올바른 위치 계산
        let newIndex = 0;
        $cardCols.each(function(index) {
            const $currentCardCol = $(this);
            const currentTotalScore = $currentCardCol.data('totalScore') || 0;

            if (totalScore > currentTotalScore) {
                newIndex = index;
                return false; // break
            }
            newIndex = index + 1;
        });

        if (currentIndex === newIndex) {
            // 위치 변경이 없으면 종료
            return;
        }

        // 카드 이동 애니메이션 적용
        cardCol.addClass('moving');

        if (newIndex === 0) {
            // 맨 앞에 삽입
            $mealsContainer.prepend(cardCol);
        } else {
            // 특정 위치에 삽입
            $mealsContainer.children('.card-col').eq(newIndex - 1).after(cardCol);
        }

        // 애니메이션 완료 후 클래스 제거
        setTimeout(function() {
            cardCol.removeClass('moving');
        }, 500); // 애니메이션 시간과 동일하게 설정
    }

    // 자동 갱신 시작
    function startAutoRefresh() {
        if (autoRefreshInterval) {
            clearInterval(autoRefreshInterval);
        }
        autoRefreshInterval = setInterval(function() {
            refreshLikesAndReposition();
        }, 30000); // 30초마다 갱신
    }

    // 자동 갱신 중지
    function stopAutoRefresh() {
        if (autoRefreshInterval) {
            clearInterval(autoRefreshInterval);
            autoRefreshInterval = null;
        }
    }

    function refreshLikesAndReposition() {
        $.ajax({
            url: `/api/reactions/${currentDate}`,
            method: 'GET',
            success: function(reactions) {
                debugger
                const $cardCols = $mealsContainer.children('.card-col');

                $cardCols.each(function() {
                    const cardCol = $(this);
                    const card = cardCol.find('.card');
                    const schoolCode = card.attr('id').split('-').pop();

                    // 해당 학교의 좋아요 데이터 가져오기
                    const reaction = reactions[schoolCode] || { likes: 0, dislikes: 0 };

                    // 좋아요 수 업데이트
                    card.find('.likes-count').text(reaction.likes);
                    update_count_ReactionUI(card, reaction);

                    // 좋아요 수를 카드 컬럼에 저장
                    cardCol.data('likes', reaction.likes);
                });

                // 좋아요 수에 따라 카드 재배치
                repositionCardsByLikes();
            },
            error: function(xhr, status, error) {
                console.error('Error fetching likes:', error);
            }
        });
    }

    function repositionCardsByLikes() {
        const $cardCols = $mealsContainer.children('.card-col').get();

        // 카드 컬럼들을 좋아요 수에 따라 정렬
        $cardCols.sort(function(a, b) {
            const likesA = $(a).data('likes') || 0;
            const likesB = $(b).data('likes') || 0;

            return likesB - likesA; // 내림차순 정렬
        });

        // 정렬된 순서대로 DOM에 다시 추가하면서 애니메이션 적용
        $.each($cardCols, function(index, cardCol) {
            $mealsContainer.append(cardCol);
            $(cardCol).addClass('moving');
            setTimeout(function() {
                $(cardCol).removeClass('moving');
            }, 500); // 애니메이션 시간과 동일하게 설정
        });
    }

    function createStars(score) {
        const fullStars = Math.floor(score);
        const hasHalfStar = score % 1 >= 0.5;
        let starsHtml = '';

        for (let i = 0; i < 5; i++) {
            if (i < fullStars) {
                starsHtml += '<i class="fas fa-star"></i>';
            } else if (i === fullStars && hasHalfStar) {
                starsHtml += '<i class="fas fa-star-half-alt"></i>';
            } else {
                starsHtml += '<i class="far fa-star"></i>';
            }
        }

        return `
            <div class="stars">
                ${starsHtml}
            </div>
            <small class="text-muted">${score.toFixed(1)}</small>
        `;
    }

    function createBasicCard(meal, index) {
        return `
            <div class="col-md-6 col-lg-4 mb-4 card-col">
                <div class="card h-100" id="school-${meal.school_code}">
                    <div class="card-header py-2 fs-5">
                    ${meal.school_name}
                    </div>
                    <div class="card-body">
                        <p class="card-text">${meal.lunch_menu}</p>
                        <div class="review-section">
                            <div class="review-loading text-center">
                                <div class="spinner-border spinner-border-sm text-primary" role="status">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                                <span class="ms-2">리뷰 생성 중...</span>
                            </div>
                            <div class="review-container"></div>
                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-between align-items-center">
                        <div class="flex-grow-1 review-score text-center d-flex justify-content-center align-items-center gap-2">
                            <div class="nutri-score"></div>
                            <div class="pref-score"></div>
                        </div>
                        <div class="reactions-container text-center">
                            <span class="reaction-btn text-muted cursor-pointer" data-type="like" 
                            data-name="${meal.school_name}"
                            data-school="${meal.school_code}">
                                <i class="fas fa-thumbs-up"></i>
                            </span>
                            <span class="likes-count">0</span>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    function handleReaction(schoolCode, reactionType, date) {
        const card = $(`#school-${schoolCode}`);

        // 특정 학교 코드에 해당하는 카드가 존재하는지 확인
        if (card.length === 0) {
            console.error(`학교 코드 ${schoolCode}에 해당하는 카드가 존재하지 않습니다.`);
            return;
        }

        $.ajax({
            url: `/api/reaction/${date}/${schoolCode}/${reactionType}`,
            method: 'POST',
            success: function(response) {
                // 카운트 업데이트
                
                // $(`#school-${response.school_code}`).text(response.likes);
                update_count_ReactionUI(card, response);

                // 좋아요 수를 카드 컬럼에 저장
                const cardCol = card.closest('.card-col');
                cardCol.data('likes', response.likes);

                // 좋아요 수에 따라 카드 재배치
                // repositionCardsByLikes();
            },
            error: function(xhr, status, error) {
                alert('반응을 저장하는 중 오류가 발생했습니다.');
            }
        });
    }

    function update_count_ReactionUI(card, response) {
         card.find('.likes-count').text( response.likes );

        if (response.likes === 0) {
            card.find('.reaction-btn').removeClass('text-primary').addClass('text-muted');
        } else {
            card.find('.reaction-btn').removeClass('text-muted').addClass('text-primary');
        }
    }

    function initializeDateButtons() {
        const today = new Date();
        const dates = [];

        for (let i = -3; i <= 3; i++) {
            const date = new Date(today);
            date.setDate(today.getDate() + i);

            // 주말(토,일) 제외
            if (date.getDay() !== 0 && date.getDay() !== 6) {
                dates.push(date.toISOString().split('T')[0]);
            }
        }

        dates.forEach(date => {
            const button = $('<button>')
                .addClass('btn btn-outline-primary date-btn')
                .attr('data-date', date)
                .text(new Date(date).toLocaleDateString('ko-KR', {
                    month: 'long',
                    day: 'numeric',
                    weekday: 'short'
                }));

            if (date === today.toISOString().split('T')[0]) {
                button.addClass('active');
            }

            $dateButtons.append(button);
        });

        fetchMeals(today.toISOString().split('T')[0]);
    }

    // 이벤트 핸들러
    $(document).on('click', '.reaction-btn', function(event) {
        event.stopPropagation();
        
        const schoolCode = $(this).data('school');
        const schoolName = $(this).data('name');
        // alert(schoolCode + "/" + schoolName);

        const reactionType = $(this).data('type');
        handleReaction(schoolCode, reactionType, currentDate);
    });

    $(document).on('click', '.date-btn', function(event) {
        event.stopPropagation();
        $('.date-btn').removeClass('active');
        $(this).addClass('active');
        fetchMeals($(this).data('date'));
    });

    // 초기화
    initializeDateButtons();
    updateVisitCount();
});
